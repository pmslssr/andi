import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

public class ReadJSONFile {
	public static void main(String[] args) {
		try {
			Data d = new Data();
			ObjectMapper mapper = new ObjectMapper();
			Map<String, Object> dataMap = mapper.readValue(new File(
					"myJSON.json"), Map.class);

			System.out.println(dataMap.get("name"));
			System.out.println(dataMap.get("adress"));
			System.out.println(dataMap.get("age"));
		
		} catch (JsonParseException e) {
			e.printStackTrace();
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}
	}

}

class Data {

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	private String age;

	public static void main(String[] args) {

	}
}
