import java.io.FileWriter;
import java.io.IOException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class CreateJSONFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		JSONObject obj = new JSONObject();
		try {
			obj.put("name", "praneeth");
			obj.put("adress", "ecospace");
			obj.put("age", 25);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try(FileWriter file = new FileWriter("myJSON.json"))
		{
			file.write(obj.toString());
			file.flush();
			
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
		System.out.println(obj);
	}

}
